package in.co.library.managment.exception;



public class DuplicateRecordException  extends Exception
{
	public DuplicateRecordException(String msg) {
		super(msg);
	}
}
